/* Check if the compiler matches the one used to build the runtime */
#ifndef MAKEDEPEND_RUN



#if GCC_VERSION != 50400
#error The version of GCC does not match the expected version (GCC 5.4.0)
#endif

#endif

